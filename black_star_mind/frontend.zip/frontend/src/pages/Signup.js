import React, { Component } from 'react';

import './Auth.css';
import AuthContext from '../context/auth-context';

class SignupPage extends Component {


  static contextType = AuthContext;

  constructor(props) {
    super(props);
    this.emailEl = React.createRef();
    this.passwordEl = React.createRef();
  }

  submitHandler = event => {
    event.preventDefault();
    const email = this.emailEl.current.value;
    const password = this.passwordEl.current.value;
    const name = this.nameEl.current.value;
    const username = this.usernameEl.current.value;

    if (email.trim().length === 0 || password.trim().length === 0) {
      return;
    }

    const requestBody = {
      query: `
        mutation CreateUser($email: String!, $password: String!) {
          createUser(userInput: {
            email: $email,
            password: $password,
            name: $name,
            username: $username,
            dob: $dob,
            phone: $phone,
            address: $address
          })
            {
            _id
            email
            name
            username
          }
        }
      `,
      variables: {
        email: email,
        password: password,
        name: name,
        username: username,
        dob: dob
      }
    };
    };



    fetch('http:localhost:8000/graphql', {
      method: 'POST',
      body: JSON.stringify(requestBody),
      headers: {
        'Content-Type': 'application/json'
      }
    })
      .then(res => {
        if (res.status !== 200 && res.status !== 201) {
          throw new Error('Failed!');
        }
        return res.json();
      })
      .then(resData => {
        console.log(JSON.stringify(resData));
      })
      .catch(err => {
        console.log(err);
      });
  };

  render() {
    return (
      <form className="auth-form" onSubmit={this.submitHandler}>
        <div className="form-control">
          <label htmlFor="email">E-Mail</label>
          <input type="email" id="email" ref={this.emailEl} />
        </div>
        <div className="form-control">
          <label htmlFor="password">Password</label>
          <input type="password" id="password" ref={this.passwordEl} />
        </div>
        <div className="form-control">
          <label htmlFor="name">Name</label>
          <input type="text" id="name" ref={this.nameEl} />
        </div>
        <div className="form-control">
          <label htmlFor="username">Username</label>
          <input type="text" id="username" ref={this.usernameEl} />
        </div>
        <div className="form-control">
          <label htmlFor="dob">D.O.B</label>
          <input type="date" id="dob" ref={this.dobEl} />
        </div>
        <div className="form-actions">
          <button type="submit">Submit</button>
        </div>
      </form>
    );
  }
}

export default AuthPage;
